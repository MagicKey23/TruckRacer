package TruckRacer;
import TruckRacer.TruckRace;
public class GameLauncher {
	public static void main(String[] args) {
		
		//Start Game
		TruckRace game = new TruckRace();
		game.playGame();
	}
	

}
