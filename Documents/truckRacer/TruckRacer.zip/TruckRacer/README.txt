The truck racer files are located in the src folder. Use Eclipse to run and compile the file.
