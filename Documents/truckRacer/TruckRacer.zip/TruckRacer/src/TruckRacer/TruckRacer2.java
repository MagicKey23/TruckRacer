
package TruckRacer;
import java.util.Random;
import java.util.Scanner;

public class TruckRacer2 {
	
		//Set UP
	 	private static String[] trucks = {"Chevy", "Ford"};
	    private static Random rnd = new Random();
	    private static Scanner input = new Scanner(System.in);
	    private static int selectTruck = 0;
	    private static String[] cities = {"El Paso", "Amarillo", "Wichita Falls", "Dallas Fort Worth", "Houston", "San Antonio", "South Padre Island"};
	    private static int[] location = {0, 0};
	    
	    public static void main (String[] agrs) {
	        boolean winner = false;
	        
	    	
	        while(!winner){
	        	System.out.printf("%s's turn. Press Enter to Spin...\n", trucks[selectTruck]);
	           
	        	//Request new location
	        	int truckLocation = getSpin();
	        	//Update new location
	            location[selectTruck] += truckLocation;
	        if(location[selectTruck] < 0) {
	        	location[selectTruck] = 0;
	        }else if(location[selectTruck] >= 6 ) {
	        	location[selectTruck] = 6;	
	        	winner = true;
	        	System.out.printf("%s is in %s and wins!!", trucks[selectTruck], cities[6]);
	        	break;
	        	}
	            	
	            
	        
	        
        	System.out.printf("%s spun %d and is in %s \n", trucks[selectTruck], truckLocation, cities[location[selectTruck]]);
        	//Continue?
        	String key_Press = input.nextLine();
            if(key_Press.isEmpty()){
		        selectTruck = selectTruck == 0 ? 1 : 0;
	        }
            else{
	        	System.out.printf("Something went wrong! You must either press space or any key on the keyboard.\n Please try again.");
	        	break;
	        }
	    }
	   }
	    
	    
	    public static int getSpin(){
	        int spinVal = rnd.nextInt(6) - 2;
	        return spinVal;
	    }
	
}