package TruckRacer;
import java.util.Random;
import java.util.Scanner;

public class TruckRacer1 {
	
		//Set UP
	 	private static String[] trucks = {"Chevy", "Ford"};
	    private static Random rnd = new Random();
	    private static Scanner input = new Scanner(System.in);
	    private static int spinCounter = 0;
	    private static int selectTruck = 0;
	    
	    
	    public static void main (String[] agrs) {
	        
	    	//Take trucks's value 10 times.
	        while(spinCounter < 10){
	        	System.out.printf("%s's turn. Press Enter to Spin...\n", trucks[selectTruck]);
	            System.out.printf("%s spun %d \n", trucks[selectTruck], getSpin());
	        	//Ask whether player wants to continue.
	            String key_Press = input.nextLine();
	        if(key_Press.isEmpty()){
		        spinCounter++;
		        selectTruck = selectTruck == 0 ? 1 : 0;
	        }else{
	        	System.out.printf("Something went wrong! You must either press space or any key on the keyboard.\n Please try again.");
	        	break;
	        	}
	    }
	   }
	    
	    
	    public static int getSpin(){
	        int spinVal = rnd.nextInt(6) - 2;
	        return spinVal;
	    }
	
}
