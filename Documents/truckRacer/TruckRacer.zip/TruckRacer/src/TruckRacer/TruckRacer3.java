package TruckRacer;
import java.util.Random;
import java.util.Scanner;

public class TruckRacer3 {
	
		//Set UP
	 	private static String[] trucks = {"Chevy", "Ford"};
	    private static Random rnd = new Random();
	    private static Scanner input = new Scanner(System.in);
	    private static int selectTruck = 0;
	    private static String[] cities = {"El Paso", "Amarillo", "Wichita Falls", "Dallas Fort Worth", "Houston", "San Antonio", "South Padre Island"};
	    private static int[] location = {0, 0};
	    
	    public static void main (String[] agrs) {
	        
	    	boolean winner = false;
	        
	    	
	        while(!winner){
	        	//Start the recorder
	        	showState();
	        	
	        	System.out.printf("%s's turn. Press Enter to Spin...\n", trucks[selectTruck]);
	           
	        	//Request new location
	        	int truckLocation = getSpin();
	        	//Update new location
	            location[selectTruck] += truckLocation;
	            //if Location doesn't exist, go back to start 
	            //and if the location is farther than the finishing line. 
	            //We can assumed the rider reached the destination
	        if(location[selectTruck] < 0) {
	        	location[selectTruck] = 0;
	        }else if(location[selectTruck] >= 6 ) {
	        	location[selectTruck] = 6;	
	        	winner = true;
	        	System.out.printf("%s is in %s and wins!!", trucks[selectTruck], cities[6]);
	        	break;
	        	}
	            
	        
        	System.out.printf("%s spun %d and is in %s \n", trucks[selectTruck], truckLocation, cities[location[selectTruck]]);
        	//Continue?
        	String key_Press = input.nextLine();
            if(key_Press.isEmpty()){
		        selectTruck = selectTruck == 0 ? 1 : 0;
	        }
            else{
	        	System.out.printf("Something went wrong! You must either press space or any key on the keyboard.\n Please try again.");
	        	break;
	        }
            
        	

	    }
	        //Update the final result.
	        showState();
	   }
	    
	    
	    public static int getSpin(){
	    	//Spin
	        int spinVal = rnd.nextInt(6) - 2;
	        return spinVal;
	    }
	    
	    
	    public static void showState() {
	    	String header = "CURRENT LOCATION: \n";
	    	for(int i = 0; i < cities.length; i++) {	    		
	    		//0 is the location for Truck 1
	    		//1 is the location for Truck 2
	    		// Print out cities if it matched with the location of the car
	    		if(cities[location[0]].equals(cities[i])) {
	    			header += String.format("%20s - %10s ",cities[i], trucks[0]);
	    		}else {header += String.format("%20s - %10s", cities[i]," ");}
	    		
	    		if(cities[location[1]].equals(cities[i])) {
	    			header += String.format("%10s\n", trucks[1]);
	    		}else {header += String.format("%10s\n", " ");}
	    		
	    	}
	    	
	    	System.out.print(header);
	    }
	    
	    
	
}








